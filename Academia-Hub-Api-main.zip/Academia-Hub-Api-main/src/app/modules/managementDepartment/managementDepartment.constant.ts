export const managementDepartmentFilterableFields = ['searchTerm', 'title']

export const managementDepartmentSearchableFields = ['title']
